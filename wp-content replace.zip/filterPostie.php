<?php
// Filtru Postie: singura etichetă cerută în titlul emailului este [public].
// [public] face postarea sticky; fără categorie și fără taguri în titlu.
// Postie salvează postarea în categoria implicită setată în Postie.
// Exemplu de titlu: "[public] Anunț privind programul de lucru"
global $postie_make_sticky;
$postie_make_sticky = false;

add_filter('postie_subject', 'pc_subject');
function pc_subject($subject) {
    global $postie_make_sticky;
    // Se reia pentru fiecare email: indicatorul nu trebuie să rămână de la emailul anterior.
    $postie_make_sticky = false;
    $subject = trim($subject);

    // [public] oriunde în titlu; se scoate din titlul postării
    if (preg_match('/\[\s*public\s*\]/iu', $subject)) {
        $postie_make_sticky = true;
        $subject = trim(preg_replace('/\s*\[\s*public\s*\]\s*/iu', ' ', $subject));
    }
    return $subject;
}

add_action('postie_post_after', 'pc_post_after');
function pc_post_after($post) {
    global $postie_make_sticky;
    if ($postie_make_sticky && !empty($post['ID'])) {
        stick_post($post['ID']);
    }
    $postie_make_sticky = false;
}
