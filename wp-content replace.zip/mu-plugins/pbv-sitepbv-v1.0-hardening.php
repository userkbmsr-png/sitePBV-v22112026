<?php
/**
 * Plugin Name: sitePBV – securitate
 * Description: Măsuri de securitate aplicabile din WordPress. Paginile și pictograma site-ului sunt gestionate acum de pluginul SetareDate.
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'pbv_v10_hide_generator', 1);
function pbv_v10_hide_generator() {
    remove_action('wp_head', 'wp_generator');
    add_filter('the_generator', '__return_empty_string');
}

// Acest pachet nu folosește XML-RPC; activați-l numai dacă o integrare verificată îl cere.
if (!defined('PBV_ALLOW_XMLRPC') || PBV_ALLOW_XMLRPC !== true) {
    add_filter('xmlrpc_enabled', '__return_false');
}

// Ascunde enumerarea utilizatorilor prin REST API pentru vizitatorii neautentificați.
add_filter('rest_endpoints', 'pbv_v10_restrict_public_user_routes');
function pbv_v10_restrict_public_user_routes($endpoints) {
    if (is_user_logged_in()) {
        return $endpoints;
    }
    unset($endpoints['/wp/v2/users']);
    unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
    return $endpoints;
}

add_action('send_headers', 'pbv_v10_send_security_headers', 10);
function pbv_v10_send_security_headers() {
    if (headers_sent()) {
        return;
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    if (function_exists('is_ssl') && is_ssl()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
