<?php
/**
 * Ziarul local: lista edițiilor PDF (stânga) și vizualizatorul larg (dreapta).
 * Se folosește automat pentru pagina cu adresa /ziarul-local/.
 *
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container pbv-container--wide">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <p class="pbv-page-intro">Edițiile ziarului local, în format PDF. Alegeți o ediție din listă pentru a o citi.</p>
        </div>
    </div>
    <div class="pbv-container pbv-container--wide pbv-page-content-wrap">
        <?php if (shortcode_exists('setaredrive_ziar')) : ?>
            <?php echo do_shortcode('[setaredrive_ziar]'); ?>
        <?php else : ?>
            <p class="pbv-announcements-empty">Activați pluginul SetareDrive pentru a afișa edițiile.</p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
