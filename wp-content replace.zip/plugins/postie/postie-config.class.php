<?php

/**
 * Strongly-Typed Configuration Data Transfer Object (DTO) for Postie Settings.
 *
 * NOTE ON BACKWARDS COMPATIBILITY:
 * Although 100% of internal codebase configuration accesses have been migrated to the
 * modern strongly-typed property syntax (e.g. `$config->post_type`), this class MUST continue 
 * to implement \ArrayAccess.
 *
 * Postie passes this `$config` object as an argument into numerous external WordPress filters
 * and action hooks (e.g., `postie_post_before`, `postie_post_after`, and attachment filters).
 * User-defined custom filters (e.g., in `filterPostie.php`) or third-party add-ons expect 
 * to read these configurations using legacy array lookups (e.g., `$config['prefer_text_type']`).
 * Removing this interface would cause fatal runtime type errors in those custom extensions.
 */
class PostieSettings implements \ArrayAccess {
    public $add_meta = 'no';
    public $admin_username = 'admin';
    public $allow_html_in_body = true;
    public $allow_html_in_subject = true;
    public $allow_subject_in_mail = true;
    public $audiotemplate = '';
    public $audiotypes = array('m4a', 'mp3', 'ogg', 'wav', 'mpeg');
    public $authorized_addresses = array();
    public $banned_files_list = array();
    public $confirmation_email = '';
    public $convertnewline = false;
    public $converturls = true;
    public $custom_image_field = false;
    public $default_post_category = null;
    public $category_match = true;
    public $default_post_tags = array();
    public $default_title = "Live From The Field";
    public $delete_mail_after_processing = true;
    public $drop_signature = true;
    public $filternewlines = true;
    public $forward_rejected_mail = true;
    public $icon_set = 'silver';
    public $icon_size = 32;
    public $auto_gallery = false;
    public $image_new_window = false;
    public $image_placeholder = '#img%#';
    public $images_append = true;
    public $imagetemplate = '';
    public $imagetemplates = array();
    public $input_protocol = 'pop3';
    public $input_connection = 'sockets';
    public $interval = 'twiceperhour';
    public $keep_unknown_emails_as_draft = true;
    public $mail_server = null;
    public $mail_server_port = 110;
    public $mail_userid = null;
    public $mail_password = null;
    public $maxemails = 0;
    public $message_start = '';
    public $message_end = '';
    public $message_encoding = 'UTF-8';
    public $message_dequote = true;
    public $post_status = 'publish';
    public $prefer_text_type = 'plain';
    public $return_to_sender = false;
    public $role_access = array();
    public $selected_audiotemplate = 'simple_link';
    public $selected_imagetemplate = 'wordpress_default';
    public $selected_video1template = 'vshortcode';
    public $selected_video2template = 'simple_link';
    public $shortcode = false;
    public $sig_pattern_list = array('--\s?[\r\n]?', '--\s', '--', '---');
    public $smtp = array();
    public $start_image_count_at_zero = false;
    public $supported_file_types = array('application');
    public $turn_authorization_off = false;
    public $time_offset = 0.0;
    public $video1template = '';
    public $video1types = array('mp4', 'mpeg4', '3gp', '3gpp', '3gpp2', '3gp2', 'mov', 'mpeg', 'quicktime');
    public $video2template = '';
    public $video2types = array('x-flv');
    public $video1templates = array();
    public $video2templates = array();
    public $wrap_pre = 'no';
    public $featured_image = false;
    public $include_featured_image = true;
    public $email_tls = false;
    public $post_format = 'standard';
    public $post_type = 'post';
    public $generaltemplates = array();
    public $generaltemplate = '';
    public $selected_generaltemplate = 'postie_default';
    public $generate_thumbnails = true;
    public $reply_as_comment = true;
    public $force_user_login = false;
    public $auto_gallery_link = 'default';
    public $ignore_mail_state = false;
    public $strip_reply = true;
    public $postie_log_error = true;
    public $postie_log_debug = false;
    public $category_colon = true;
    public $category_dash = true;
    public $category_bracket = true;
    public $prefer_text_convert = true;
    public $category_remove = true;
    public $ignore_email_date = false;
    public $use_time_offset = false;
    public $postie_log_error_notify = '(All Admins)';
    public $image_resize = true;
    public $duplicate_comments = true;
    public $legacy_commands = true;
    public $add_wrapper_div = true;

    public function __construct(array $data) {
        foreach ($data as $key => $val) {
            if (property_exists($this, $key)) {
                $this->$key = $this->castValue($key, $val);
            }
        }
    }

    private function castValue(string $key, $value) {
        if ($value === null) {
            if (in_array($key, array('default_post_category', 'mail_server', 'mail_userid', 'mail_password'))) {
                return null;
            }
        }

        $boolKeys = array(
            'allow_html_in_body', 'allow_html_in_subject', 'allow_subject_in_mail', 'convertnewline', 'converturls',
            'custom_image_field', 'category_match', 'delete_mail_after_processing', 'drop_signature', 'filternewlines',
            'forward_rejected_mail', 'auto_gallery', 'image_new_window', 'message_dequote', 'return_to_sender',
            'shortcode', 'start_image_count_at_zero', 'turn_authorization_off', 'featured_image', 'include_featured_image',
            'email_tls', 'generate_thumbnails', 'reply_as_comment', 'force_user_login', 'ignore_mail_state', 'strip_reply',
            'postie_log_error', 'postie_log_debug', 'category_colon', 'category_dash', 'category_bracket',
            'prefer_text_convert', 'category_remove', 'ignore_email_date', 'use_time_offset', 'image_resize',
            'duplicate_comments', 'legacy_commands', 'add_wrapper_div', 'keep_unknown_emails_as_draft'
        );

        $intKeys = array('icon_size', 'mail_server_port', 'maxemails');
        $floatKeys = array('time_offset');
        $arrayKeys = array(
            'audiotypes', 'authorized_addresses', 'banned_files_list', 'default_post_tags', 'imagetemplates',
            'role_access', 'sig_pattern_list', 'smtp', 'supported_file_types', 'video1types', 'video2types',
            'video1templates', 'video2templates', 'generaltemplates'
        );

        if (in_array($key, $boolKeys)) {
            if ($value === 'yes' || $value === '1' || $value === 1 || $value === true) {
                return true;
            }
            if ($value === 'no' || $value === '0' || $value === 0 || $value === false) {
                return false;
            }
            return (bool)$value;
        }

        if (in_array($key, $intKeys)) {
            return (int)$value;
        }

        if (in_array($key, $floatKeys)) {
            return (float)$value;
        }

        if (in_array($key, $arrayKeys)) {
            return (array)$value;
        }

        return (string)$value;
    }

    #[\ReturnTypeWillChange]
    public function offsetExists($offset): bool {
        return property_exists($this, $offset);
    }

    #[\ReturnTypeWillChange]
    public function offsetGet($offset) {
        if (property_exists($this, $offset)) {
            return $this->$offset;
        }
        return null;
    }

    #[\ReturnTypeWillChange]
    public function offsetSet($offset, $value) {
        if (property_exists($this, $offset)) {
            $this->$offset = $this->castValue($offset, $value);
        }
    }

    #[\ReturnTypeWillChange]
    public function offsetUnset($offset) {
        // Settings properties are not unset.
    }

    public function toArray(): array {
        return get_object_vars($this);
    }

    public function toSafeArray(): array {
        $data = $this->toArray();
        unset($data['mail_password']);
        return $data;
    }

    public function __debugInfo() {
        return $this->toSafeArray();
    }
}

class PostieConfig {

    /**
     *
     * @var PostieSettings
     */
    private $config;

    function __construct() {
        $this->config = $this->config_fetch();
    }

    function config_fetch() {
        $config = get_option('postie-settings');
        return new PostieSettings($this->normalize_settings($config));
    }

    /**
     * Alias to support legacy registered validation callback in postie.php
     */
    function config_ValidateSettings($in) {
        return $this->validate_settings($in);
    }

    /**
     * 
     * @return PostieSettings
     */
    function config_read() {
        return $this->config;
    }

    /**
     * normalizes and sanitizes settings to be used in the PostieSettings DTO
     */
    function normalize_settings($in) {
        $out = array();

        // use the default as a template: 
        // if a field is present in the defaults, we want to store it; otherwise we discard it
        $allowed_keys = $this->defaults();
        foreach ($allowed_keys as $key => $default) {
            if (is_array($in)) {
                $out[$key] = array_key_exists($key, $in) ? $in[$key] : $default;
            } else {
                $out[$key] = $default;
            }
        }

        // some fields are always forced to lower case:
        $lowercase = array('authorized_addresses', 'smtp', 'supported_file_types', 'video1types', 'video2types', 'audiotypes');
        foreach ($lowercase as $field) {
            $out[$field] = ( is_array($out[$field]) ) ? array_map("strtolower", $out[$field]) : strtolower($out[$field]);
        }
        $arrays = $this->arrayed_settings();

        foreach ($arrays as $sep => $fields) {
            foreach ($fields as $field) {
                if (!is_array($out[$field])) {
                    $out[$field] = explode($sep, trim($out[$field]));
                }
                foreach ($out[$field] as $key => $val) {
                    $tst = trim($val);
                    if (empty($tst)) {
                        unset($out[$field][$key]);
                    } else {
                        $out[$field][$key] = $tst;
                    }
                }
            }
        }

        $out['message_encoding'] = 'UTF-8'; //force to UTF-8;
        return $out;
    }

    /**
     * validates the config form output, fills in any gaps by using the defaults,
     * and ensures that arrayed items are stored as such, while triggering necessary
     * side effects (permissions and cron) only on save.
     */
    function validate_settings($in) {
        //DebugEcho("config_ValidateSettings");
        $out = $this->normalize_settings($in);
        $this->fix_permission_cron($out);
        return $out;
    }

    /**
     * This function used to handle updating the configuration.
     * @return boolean
     */
    function fix_permission_cron($data) {
        $this->update_permissions($data['role_access']);
        // We also update the cron settings
        PostieInit::postie_cron_hook($data['interval']);
    }

    /**
     * This function handles setting up the basic permissions
     */
    function update_permissions($role_access) {
        global $wp_roles;
        if (is_object($wp_roles)) {
            $admin = $wp_roles->get_role('administrator');
            if (!empty($admin)) {
                $admin->add_cap('config_postie');
                $admin->add_cap('post_via_postie');

                if (!is_array($role_access)) {
                    $role_access = array();
                }
                foreach ($wp_roles->role_names as $roleId => $name) {
                    $role = $wp_roles->get_role($roleId);
                    if ($roleId != 'administrator') {
                        if (array_key_exists($roleId, $role_access)) {
                            $role->add_cap('post_via_postie');
                            //DebugEcho("added $roleId");
                        } else {
                            $role->remove_cap('post_via_postie');
                            //DebugEcho("removed $roleId");
                        }
                    }
                }
            }
        }
    }

    /**
     * Returns a list of config keys that should be arrays
     * @return array
     */
    function arrayed_settings() {
        return array(
            ', ' => array('audiotypes', 'video1types', 'video2types', 'default_post_tags'),
            "\n" => array('smtp', 'authorized_addresses', 'supported_file_types', 'banned_files_list', 'sig_pattern_list'));
    }

    /**
     * return an array of the config defaults
     */
    function defaults() {
        include('templates/audio_templates.php');
        include('templates/image_templates.php');
        include('templates/video1_templates.php');
        include('templates/video2_templates.php');
        include('templates/general_template.php');

        $defaults = get_class_vars('PostieSettings');

        $defaults['audiotemplate'] = $simple_link;
        $defaults['imagetemplate'] = $wordpress_default;
        $defaults['imagetemplates'] = $imageTemplates;
        $defaults['time_offset'] = get_option('gmt_offset');
        $defaults['video1template'] = $simple_link;
        $defaults['video2template'] = $simple_link;
        $defaults['video1templates'] = $video1Templates;
        $defaults['video2templates'] = $video2Templates;
        $defaults['generaltemplates'] = $generalTemplates;
        $defaults['generaltemplate'] = $postie_default;

        return $defaults;
    }

    /**
     * This function resets all the configuration options to the default
     */
    function reset_to_default() {
        $newconfig = $this->defaults();
        $config = get_option('postie-settings');
        $save_keys = array('mail_password', 'mail_server', 'mail_server_port', 'mail_userid', 'input_protocol', 'input_connection');
        foreach ($save_keys as $key) {
            $newconfig[$key] = $config[$key];
        }
        update_option('postie-settings', $newconfig);
        $this->fix_permission_cron($newconfig);
        return $newconfig;
    }
}
