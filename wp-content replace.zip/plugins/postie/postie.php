<?php

/*
  Plugin Name: Postie
  Plugin URI: http://PostiePlugin.com/
  Description: Create posts via email. Significantly upgrades the Post by Email features of WordPress.
  Version: 1.9.91
  Author: Wayne Allen
  Author URI: http://PostiePlugin.com/
  License: GPL3
  Text Domain: postie
 */

/*  Copyright (c) 2015-20  Wayne Allen  (email : wayne@postieplugin.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
  $Id: postie.php 3798962 2026-11-12 17:43:21Z WayneAllen $
 */

if (!defined('WPINC')) {
    die; // Exit if accessed directly
}

$plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), false);
$plugin_version = $plugin_data['Version'];

define('POSTIE_VERSION', $plugin_version);
define('POSTIE_ROOT', __DIR__);
define('POSTIE_URL', plugin_dir_url(__FILE__));

require_once(__DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'postie-compatibility.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'postie-api.php');

if (!class_exists('PostieInit')) {

    class PostieInit {

        public function __construct() {
            //WordPress Actions
            add_action('init', array($this, 'init_action'), 20);
            add_action('admin_init', array($this, 'admin_init_action'));
            add_action('admin_menu', array($this, 'admin_menu_action'));
            add_action('admin_head', array($this, 'admin_head_action'));
            add_action('plugins_loaded', array($this, 'plugins_loaded_action'));
            add_action('pre_post_update', array($this, 'pre_post_update_action'), 10, 2);

            //WordPress filters
            if (version_compare(get_bloginfo('version'), '5.5', '>=')) {
                add_filter('allowed_options', array($this, 'whitelist_options_filter'));
            } else {

                add_filter('whitelist_options', array($this, 'whitelist_options_filter'));
            }
            add_filter('cron_schedules', array($this, 'cron_schedules_filter'));
            add_filter("plugin_action_links_" . plugin_basename(__FILE__), array($this, 'plugin_action_links_filter'));
            add_filter('plugin_row_meta', array($this, 'plugin_row_meta_filter'), 10, 2);
            add_filter('enable_post_by_email_configuration', array($this, 'enable_post_by_email_configuration'));
            add_filter('site_status_tests', array($this, 'site_status_tests_filter'));
            add_filter('query', array($this, 'query_filter'));

            //WordPress Hooks
            register_activation_hook(__FILE__, array('PostieInit', 'postie_activate_hook'));
            register_activation_hook(__FILE__, array('PostieInit', 'postie_cron_hook'));
            register_deactivation_hook(__FILE__, array('PostieInit', 'postie_decron_hook'));

            //Postie actions
            add_action('check_postie_hook', 'postie_check');
            add_action('wp_ajax_postie_run_manual', array($this, 'ajax_run_manual'));
            add_action('wp_ajax_postie_test_config', array($this, 'ajax_test_config'));

            if (is_admin()) {
                $this->postie_warnings();
            }
        }

        static function postie_activate_hook() {
            /*
             * called by WP when activating the plugin
             * Note that you can't do any output during this funtion or activation
             * will fail on some systems. This means no DebugEcho, EchoInfo or DebugDump.
             */
        }

        static function postie_cron_hook($interval = false) {
            //Do not echo output in filters, it seems to break some installs
            //error_log("postie_cron: setting up cron task: $interval");
            //$schedules = wp_get_schedules();
            //error_log("postie_cron\n" . print_r($schedules, true));

            if (empty($interval)) {
                $interval = 'hourly';
                //error_log("Postie: setting up cron task: defaulting to hourly");
            }

            if ($interval == 'manual') {
                PostieInit::postie_decron_hook();
                //error_log("postie_cron: clearing cron (manual)");
            } else {
                if ($interval != wp_get_schedule('check_postie_hook')) {
                    PostieInit::postie_decron_hook(); //remove existing
                    //try to create the new schedule with the first run in 5 minutes
                    if (false === wp_schedule_event(time() + 5 * 60, $interval, 'check_postie_hook')) {
                        //error_log("postie_cron: Failed to set up cron task: $interval");
                    } else {
                        //error_log("postie_cron: Set up cron task: $interval");
                    }
                } else {
                    //error_log("postie_cron: OK: $interval");
                    //don't need to do anything, cron already scheduled
                }
            }
        }

        static function postie_decron_hook() {
            //don't use DebugEcho or EchoInfo here as it is not defined when called as a hook
            //error_log("postie_decron: clearing cron");
            wp_clear_scheduled_hook('check_postie_hook');
        }

        function site_status_tests_filter($tests) {
            $tests['direct']['postie1'] = array(
                'label' => __('Postie Test', 'postie'),
                'test' => array($this, 'test_delete_mail_after_processing'),
            );
            $tests['direct']['postie2'] = array(
                'label' => __('Postie Test', 'postie'),
                'test' => array($this, 'test_turn_authorization_off'),
            );
            return $tests;
        }

        function query_filter($query) {
            if (Postie::is_debugmode()) {
                DebugEcho("Query: $query");
            }

            return $query;
        }

        //https://make.wordpress.org/core/2019/04/25/site-health-check-in-5-2/
        function test_delete_mail_after_processing() {
            $config = postie_config_read();
            $enabled = $config->delete_mail_after_processing;
            $result = array(
                'label' => __('Postie should delete emails after processing', 'postie'),
                'status' => $enabled ? 'good' : 'recommended',
                'badge' => array(
                    'label' => __('Performance', 'postie'),
                    'color' => 'blue',
                ),
                'description' => sprintf('<p>%s</p>', __('If emails are not deleted they will be imported every time Postie runs.', 'postie')
                ),
                'actions' => '',
                'test' => 'postie_delete_mail_after_processing',
            );

            return $result;
        }

        function test_turn_authorization_off() {
            $config = postie_config_read();
            $enabled = !$config->turn_authorization_off;
            $result = array(
                'label' => __('Postie should only allow authorized users to post', 'postie'),
                'status' => $enabled ? 'good' : 'critical',
                'badge' => array(
                    'label' => __('Security', 'postie'),
                    'color' => 'blue',
                ),
                'description' => sprintf('<p>%s</p>', __('Allowing anyone who knows your Postie email address to post can result in unwanted posts.', 'postie')
                ),
                'actions' => '',
                'test' => 'postie_turn_authorization_off',
            );

            return $result;
        }

        function pre_post_update_action($post_id, $post_data) {
            DebugEcho('pre_post_update');
            DebugDump($post_data);
        }

        function plugins_loaded_action() {
            // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound
            load_plugin_textdomain('postie', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        function init_action() {
            global $wp_version;
            $version = isset($wp_version) ? $wp_version : '0.0';
            if (version_compare($version, '5.3') == -1) {
                require_once( ABSPATH . WPINC . '/class-oembed.php' );
            } else {
                require_once( ABSPATH . WPINC . '/class-wp-oembed.php' );
            }

            // Self-healing cron check: re-schedule if event is missing and interval is not 'manual'
            $config = postie_config_read();
            if ($config->interval !== 'manual' && !wp_next_scheduled('check_postie_hook')) {
                PostieInit::postie_cron_hook($config->interval);
            }
        }

        function enable_post_by_email_configuration($enabled) {
            return false;
        }

        function plugin_row_meta_filter($links, $file) {
            if (strpos($file, strval(plugin_basename(__FILE__))) !== false) {
                $new_links = array(
                    '<a href="http://postieplugin.com/" target="_blank">Support</a>',
                    '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=s-xclick&hosted_button_id=HPK99BJ88V4C2" target="_blank">Donate</a>'
                );

                $links = array_merge($links, $new_links);
            }

            return $links;
        }

        function admin_init_action() {
            wp_register_style('postie-style', plugins_url('css/style.css', __FILE__), array(), POSTIE_VERSION);
            wp_register_script('postie-admin-script', plugins_url('js/postie-admin.js', __FILE__), array('jquery'), POSTIE_VERSION, true);
            wp_localize_script('postie-admin-script', 'postieAdminData', array(
                'iconDir'     => POSTIE_URL . 'icons',
                'templateDir' => POSTIE_URL . 'templates',
                'siteUrl'     => get_option('siteurl'),
                'ajaxUrl'     => admin_url('admin-ajax.php'),
                'nonce'       => wp_create_nonce('postie_action_nonce_action'),
                'strings'     => array(
                    'processing'        => __('Processing emails...', 'postie'),
                    'processingDebug'   => __('Processing emails with debug output...', 'postie'),
                    'processingDesc'    => __('Connecting to mail server and checking for new messages. Please wait...', 'postie'),
                    'processComplete'   => __('Email Processing Complete', 'postie'),
                    'processFailed'     => __('Email Processing Failed', 'postie'),
                    'noEmails'          => __('Mailbox checked. No new emails found.', 'postie'),
                    'close'             => __('Close', 'postie'),
                    'viewPost'          => __('View', 'postie'),
                    'editPost'          => __('Edit', 'postie'),
                    'viewComment'       => __('View Comment', 'postie'),
                    'copyLogs'          => __('Copy Logs', 'postie'),
                    'copied'            => __('Copied!', 'postie'),
                    'postsCreated'      => __('Posts Created', 'postie'),
                    'commentsCreated'   => __('Comments Created', 'postie'),
                    'messagesSkipped'   => __('Messages Skipped', 'postie'),
                    'errorsEncountered' => __('Errors Encountered', 'postie'),
                    'serverError'       => __('An unexpected server error occurred.', 'postie'),
                    'testingConfig'     => __('Testing configuration...', 'postie'),
                    'testingConfigDesc' => __('Connecting to mail server and verifying configuration. Please wait...', 'postie'),
                    'testComplete'      => __('Configuration Test Complete', 'postie'),
                    'testFailed'        => __('Configuration Test Failed', 'postie'),
                    'connSuccess'       => __('Mail server connected successfully!', 'postie'),
                    'connFailed'        => __('Mail server connection failed', 'postie'),
                ),
            ));
            register_setting('postie-settings', 'postie-settings', array($this, 'lazy_validate_settings'));
        }

        function ajax_run_manual() {
            $nonce = isset($_POST['postie_action_nonce']) ? sanitize_key(wp_unslash($_POST['postie_action_nonce'])) : '';
            if (empty($nonce) || !wp_verify_nonce($nonce, 'postie_action_nonce_action')) {
                wp_send_json_error(array(
                    'message' => __('Security check failed. Please refresh the page and try again.', 'postie'),
                ));
            }

            if (!current_user_can('manage_options')) {
                wp_send_json_error(array(
                    'message' => __('You do not have sufficient permissions to perform this action.', 'postie'),
                ));
            }

            $debug = isset($_POST['debug']) && ($_POST['debug'] === 'true' || $_POST['debug'] === '1' || $_POST['debug'] === 1);
            if ($debug && !defined('POSTIE_DEBUG')) {
                define('POSTIE_DEBUG', true);
            }

            $logs = array();
            $log_collector = function($msg) use (&$logs) {
                if (is_scalar($msg)) {
                    $logs[] = (string) $msg;
                } else {
                    $logs[] = print_r(postie_sanitize_debug_data($msg), true);
                }
            };
            add_action('postie_log_debug', $log_collector);

            if (function_exists('set_time_limit')) {
                @set_time_limit(300);
            }

            ob_start();
            $start_time = microtime(true);
            $result = null;
            $error_message = null;

            try {
                $result = postie_get_mail();
            } catch (Throwable $t) {
                $error_message = $t->getMessage();
            }

            $raw_output = ob_get_clean();
            remove_action('postie_log_debug', $log_collector);

            $duration = round(microtime(true) - $start_time, 2);

            if (!empty($raw_output) && empty($logs)) {
                $logs[] = strip_tags($raw_output);
            }

            if ($error_message !== null) {
                wp_send_json_error(array(
                    'message'  => $error_message,
                    'duration' => $duration . 's',
                    'debug'    => $debug,
                    'logs'     => $logs,
                ));
            }

            wp_send_json_success(array(
                'result'   => $result,
                'duration' => $duration . 's',
                'debug'    => $debug,
                'logs'     => $logs,
            ));
        }

        function ajax_test_config() {
            $nonce = isset($_POST['postie_action_nonce']) ? sanitize_key(wp_unslash($_POST['postie_action_nonce'])) : '';
            if (empty($nonce) || !wp_verify_nonce($nonce, 'postie_action_nonce_action')) {
                wp_send_json_error(array(
                    'message' => __('Security check failed. Please refresh the page and try again.', 'postie'),
                ));
            }

            if (!current_user_can('manage_options')) {
                wp_send_json_error(array(
                    'message' => __('You do not have sufficient permissions to perform this action.', 'postie'),
                ));
            }

            global $g_postie;
            if (empty($g_postie)) {
                $g_postie = new Postie();
            }

            $logs = array();
            $log_collector = function($msg) use (&$logs) {
                if (is_scalar($msg)) {
                    $logs[] = (string) $msg;
                } else {
                    $logs[] = print_r(postie_sanitize_debug_data($msg), true);
                }
            };
            add_action('postie_log_debug', $log_collector);

            if (function_exists('set_time_limit')) {
                @set_time_limit(120);
            }

            ob_start();
            $start_time = microtime(true);
            $result = null;
            $error_message = null;

            try {
                $g_postie->postie_environment(true);
                $g_postie->postie_environment_encoding(true);
                $result = $g_postie->run_config_test();
            } catch (Throwable $t) {
                $error_message = $t->getMessage();
            }

            $raw_output = ob_get_clean();
            remove_action('postie_log_debug', $log_collector);

            $duration = round(microtime(true) - $start_time, 2);

            if (!empty($raw_output) && empty($logs)) {
                $logs[] = strip_tags($raw_output);
            }

            if ($error_message !== null) {
                wp_send_json_error(array(
                    'message'  => $error_message,
                    'duration' => $duration . 's',
                    'logs'     => $logs,
                ));
            }

            wp_send_json_success(array(
                'result'   => $result,
                'duration' => $duration . 's',
                'logs'     => $logs,
            ));
        }

        function lazy_validate_settings($in) {
            $pconfig = new PostieConfig();
            return $pconfig->config_ValidateSettings($in);
        }

        function admin_menu_action() {
            $page = add_menu_page('Postie', 'Postie', 'manage_options', 'postie-settings', array($this, 'postie_show_config_page'));
            add_action('admin_print_styles-' . $page, array($this, 'postie_admin_styles'));
        }

        function admin_head_action() {
            ?>
            <style type="text/css">
                #adminmenu #toplevel_page_postie-settings div.wp-menu-image:before {
                    content: "\f466";
                }
            </style>
            <?php

        }

        function whitelist_options_filter($options) {
            $added = array('postie-settings' => array('postie-settings'));
            return add_allowed_options($added, $options);
        }

        function cron_schedules_filter($schedules) {
            //Do not echo output in filters, it seems to break some installs
            //error_log("cron_schedules_filter: setting cron schedules");
            $schedules['weekly'] = array('interval' => (60 * 60 * 24 * 7), 'display' => __('Once Weekly', 'postie'));
            $schedules['twohours'] = array('interval' => 60 * 60 * 2, 'display' => __('Every 2 hours', 'postie'));
            $schedules['twiceperhour'] = array('interval' => 60 * 30, 'display' => __('Twice per hour', 'postie'));
            $schedules['tenminutes'] = array('interval' => 60 * 10, 'display' => __('Every 10 minutes', 'postie'));
            $schedules['fiveminutes'] = array('interval' => 60 * 5, 'display' => __('Every 5 minutes', 'postie'));
            $schedules['oneminute'] = array('interval' => 60 * 1, 'display' => __('Every 1 minute', 'postie'));
            $schedules['thirtyseconds'] = array('interval' => 30, 'display' => __('Every 30 seconds', 'postie'));
            $schedules['fifteenseconds'] = array('interval' => 15, 'display' => __('Every 15 seconds', 'postie'));
            return $schedules;
        }

        function plugin_action_links_filter($links) {
            $links[] = '<a href="admin.php?page=postie-settings">Settings</a>';
            return $links;
        }

        function postie_show_config_page() {
            global $g_postie;
            require_once POSTIE_ROOT . '/admin/views/settings-page.php';
        }

        function postie_admin_styles() {
            wp_enqueue_style('postie-style');
            wp_enqueue_script('postie-admin-script');
        }

        /**
         * This function looks for markdown which causes problems with postie
         */
        function postie_isMarkdownInstalled() {
            if (in_array("markdown.php", get_option("active_plugins"))) {
                return true;
            }
            return false;
        }

        function postie_markdown_warning() {
            echo "<div id='postie-lst-warning' class='error'><p><strong>";
            esc_html_e("You currently have the Markdown plugin installed. It will cause problems if you send in HTML email. Please turn it off if you intend to send email using HTML.", 'postie');
            echo "</strong></p></div>";
        }

        function postie_enter_info() {
            echo "<div id='postie-info-warning' class='updated fade'><p><strong>" . esc_html__('Postie is almost ready.', 'postie') . "</strong> "
            . wp_kses_post( sprintf(
                /* translators: %1$s: URL to Postie settings page */
                __('You must <a href="%1$s">enter your email settings</a> for it to work.', 'postie'),
                "admin.php?page=postie-settings"
            ) )
            . "</p></div> ";
        }

        function postie_iconv_warning() {
            echo "<div id='postie-lst-warning' class='error'><p><strong>";
            esc_html_e("Warning! Postie requires that iconv be enabled.", 'postie');
            echo "</strong></p></div>";
        }

        function postie_php_warning() {
            echo "<div id='postie-lst-warning' class='error'><p><strong>";
            /* translators: %s: PHP version */
            printf( esc_html__( "Warning! Postie requires that PHP be verion 7 or higher. You have version %s", 'postie' ), esc_html( phpversion() ) );
            echo "</strong></p></div>";
        }

        function postie_curl_warning() {
            $cv = curl_version();
            echo "<div id='postie-lst-warning' class='error'><p><strong>";
            /* translators: %s: curl version */
            printf( esc_html__( "Warning! Postie requires cURL 7.30.0 or newer be installed. %s is installed.", 'postie' ), esc_html( $cv['version'] ) );
            echo "</strong></p></div>";
        }

        function postie_adminuser_warning() {
            echo "<div id='postie-mbstring-warning' class='error'><p><strong>";
            esc_html_e('Warning: the Default Poster is not a valid WordPress login. Postie may reject emails if this is not corrected.', 'postie');
            echo "</strong></p></div>";
        }

        function postie_IsIconvInstalled($display = true) {
            $function_list = array('iconv');
            return($this->postie_HasFunctions($function_list, $display));
        }

        /**
         * Handles verifying that a list of functions exists
         * @return boolean
         * @param array
         */
        function postie_HasFunctions($function_list, $display = true) {
            foreach ($function_list as $function) {
                if (!function_exists($function)) {
                    if ($display) {
                        EchoError("Missing $function");
                    }
                    return false;
                }
            }
            return true;
        }

        function postie_warnings() {
            $config = postie_config_read();

            if ((empty($config->mail_server) ||
                    empty($config->mail_server_port) ||
                    empty($config->mail_userid) ||
                    empty($config->mail_password)
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    ) && !isset($_POST['submit'])) {

                add_action('admin_notices', array($this, 'postie_enter_info'));
            }

            if ($this->postie_isMarkdownInstalled() && $config->prefer_text_type == 'html') {
                add_action('admin_notices', array($this, 'postie_markdown_warning'));
            }

            if (!$this->postie_IsIconvInstalled()) {
                add_action('admin_notices', array($this, 'postie_iconv_warning'));
            }

            if (!fCore::checkVersion('7.0')) {
                add_action('admin_notices', array($this, 'postie_php_warning'));
            }

            if (function_exists('curl_version')) {
                $cv = curl_version();
            } else {
                $cv['version'] = '1.0.0';
            }
            if ($config->input_connection == 'curl' && !version_compare($cv['version'], '7.30.0', 'ge')) {
                add_action('admin_notices', array($this, 'postie_curl_warning'));
            }

            $userdata = WP_User::get_data_by('login', $config->admin_username);
            if (!$userdata) {
                add_action('admin_notices', array($this, 'postie_adminuser_warning'));
            }
        }
    }

    global $g_postie_init; //need to declare as global for wp cli
    $g_postie_init = new PostieInit();
}
