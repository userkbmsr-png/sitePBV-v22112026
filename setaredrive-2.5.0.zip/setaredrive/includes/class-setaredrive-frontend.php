<?php
/**
 * Pagini publice: Formulare, Media (carusel) și Monitorul Oficial Local (arbore de foldere).
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDrive_Frontend {
    const REST_NS = 'setaredrive/v1';

    public static function init() {
        $map = array(
            'setaredrive_formulare' => 'formulare',
            'setaredrive_media'     => 'media',
            'setaredrive_mol'       => 'mol',
            'setaredrive_ziar'      => 'ziar',
            'setaredrive_formulare_compartiment' => 'service_shortcode',
            // Nume vechi, păstrate pentru paginile create de pluginul anterior.
            'pbv_formulare'         => 'formulare',
            'pbv_media_gallery'     => 'media',
            'pbv_mol_browser'       => 'mol',
        );
        foreach ($map as $tag => $method) {
            add_shortcode($tag, array(__CLASS__, $method));
        }
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_filter('the_content', array(__CLASS__, 'append_service_forms'), 20);
        add_action('rest_api_init', array(__CLASS__, 'routes'));
    }

    /* ----------------------------------------------------------------- resurse */

    public static function register_assets() {
        wp_register_style('setaredrive', SETAREDRIVE_URL . 'assets/setaredrive.css', array(), SETAREDRIVE_VERSION);
        wp_register_script('setaredrive', SETAREDRIVE_URL . 'assets/setaredrive.js', array(), SETAREDRIVE_VERSION, true);
        wp_register_script('setaredrive-media', SETAREDRIVE_URL . 'assets/setaredrive-media.js', array(), SETAREDRIVE_VERSION, true);
        wp_register_script('setaredrive-ziar', SETAREDRIVE_URL . 'assets/setaredrive-ziar.js', array(), SETAREDRIVE_VERSION, true);
        wp_register_script('setaredrive-svc', SETAREDRIVE_URL . 'assets/setaredrive-svc.js', array(), SETAREDRIVE_VERSION, true);

        if (is_page(array('formulare', 'monitorul-oficial-local', 'media', 'ziarul-local'))) {
            self::enqueue('browser');
            self::enqueue('media');
            self::enqueue('ziar');
            return;
        }
        $post = get_post();
        if ($post instanceof WP_Post && is_singular()) {
            foreach (array('setaredrive_formulare', 'pbv_formulare', 'setaredrive_mol', 'pbv_mol_browser') as $tag) {
                if (has_shortcode($post->post_content, $tag)) {
                    self::enqueue('browser');
                }
            }
            foreach (array('setaredrive_media', 'pbv_media_gallery') as $tag) {
                if (has_shortcode($post->post_content, $tag)) {
                    self::enqueue('media');
                }
            }
            if (has_shortcode($post->post_content, 'setaredrive_ziar')) {
                self::enqueue('ziar');
            }
        }
    }

    private static function enqueue($kind) {
        wp_enqueue_style('setaredrive');
        if ($kind === 'media') {
            wp_enqueue_script('setaredrive-media');
            return;
        }
        if ($kind === 'ziar') {
            wp_enqueue_script('setaredrive-ziar');
            return;
        }
        if ($kind === 'svc') {
            wp_enqueue_script('setaredrive-svc');
            wp_localize_script('setaredrive-svc', 'SetareDriveSvc', array('rest' => esc_url_raw(rest_url(self::REST_NS . '/'))));
            return;
        }
        wp_enqueue_script('setaredrive');
        wp_localize_script('setaredrive', 'SetareDrive', array(
            'rest'    => esc_url_raw(rest_url(self::REST_NS . '/')),
            'strings' => array(
                'selectFirst' => 'Selectați mai întâi un folder din listă.',
                'enterTerm'   => 'Introduceți un termen de căutare.',
                'searching'   => 'Se caută fișiere în folderul selectat…',
                'noResults'   => 'Nu au fost găsite fișiere cu acest nume în folderul selectat.',
                'found'       => 'fișiere găsite',
                'failed'      => 'Căutarea nu a putut fi efectuată momentan.',
                'searchIn'    => 'Căutare în',
                'searchAll'   => 'Căutare în tot Monitorul Oficial Local',
                'partial'     => 'Rezultatele sunt parțiale (arhiva este foarte mare sau a durat prea mult). Restrângeți căutarea sau alegeți un folder.',
                'loading'     => 'Se încarcă…',
                'showChildren' => 'Arată subfolderele',
                'hideChildren' => 'Ascunde subfolderele',
                'docOne'      => 'document',
                'docMany'     => 'documente',
                'emptyFolder' => 'Acest folder nu conține documente.',
                'emptyCompartment' => 'Nu există încă formulare pentru acest compartiment.',
                'onlySubfolders' => 'Acest folder conține doar subfoldere. Alegeți un subfolder din listă pentru a vedea documentele.',
                'listFailed'  => 'Lista de documente nu poate fi încărcată momentan.',
            ),
        ));
    }

    /* ------------------------------------------------------------------- utile */

    private static function notice($title, $message, $admin_detail = '') {
        $extra = ($admin_detail !== '' && current_user_can('manage_options')) ? '<p class="sdrv-admin-note">' . esc_html($admin_detail) . '</p>' : '';
        return '<div class="sdrv-notice"><strong>' . esc_html($title) . '</strong><p>' . esc_html($message) . '</p>' . $extra . '</div>';
    }

    private static function embed_url($id) {
        return 'https://drive.google.com/embeddedfolderview?id=' . rawurlencode($id) . '#list';
    }

    private static function open_url($id) {
        return 'https://drive.google.com/drive/folders/' . rawurlencode($id);
    }

    private static function viewer_frame() {
        return '<div class="sdrv-frame-wrap"><iframe class="sdrv-frame" data-frame title="Documentele din folderul selectat" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>'
            . '<p class="sdrv-open"><a data-open-link href="https://drive.google.com" target="_blank" rel="noopener noreferrer">Deschide folderul în Google Drive</a></p>';
    }

    /**
     * Sursa activă a unei secțiuni: folderul de pe server (dacă e setat și valid), altfel Google Drive.
     *
     * @return array{type:string,id?:string,detail:string}
     */
    private static function source($section) {
        $detail = '';
        $local  = SetareDrive_Local::root($section);
        if (!is_wp_error($local)) {
            return array('type' => 'local', 'detail' => '');
        }
        if (SetareDrive_Local::option($section) !== '') {
            $detail = $local->get_error_message();
        }
        $drive = SetareDrive_API::folder_option($section);
        if ($drive !== '') {
            return array('type' => 'drive', 'id' => $drive, 'detail' => $detail);
        }
        return array('type' => 'none', 'detail' => $detail);
    }

    private static function count_label($count) {
        return $count . ' ' . ($count === 1 ? 'document' : 'documente');
    }

    private static function local_name($section, $rel) {
        if ($rel !== '') {
            return basename($rel);
        }
        $root = SetareDrive_Local::root($section);
        return is_wp_error($root) ? '' : basename($root);
    }

    /** Lista de documente a unui folder de pe server (aceeași structură este refăcută în JavaScript). */
    private static function local_list($section, $rel, $name) {
        $files = SetareDrive_Local::files($section, $rel);
        $files = is_wp_error($files) ? array() : $files;
        $html  = '<div class="sdrv-folder-head"><span class="sdrv-folder-icon" aria-hidden="true">📁</span><div><h3>' . esc_html($name) . '</h3><p>' . esc_html(self::count_label(count($files))) . '</p></div></div>';
        if (!$files) {
            $sub = SetareDrive_Local::folders($section, $rel);
            $none = $section === 'formulare' ? 'Nu există încă formulare pentru acest compartiment.' : 'Acest folder nu conține documente.';
            $msg  = (!is_wp_error($sub) && $sub) ? 'Acest folder conține doar subfoldere. Alegeți un subfolder din listă pentru a vedea documentele.' : $none;
            return $html . '<p class="sdrv-empty">' . esc_html($msg) . '</p>';
        }
        $html .= '<ul class="sdrv-doclist">';
        foreach ($files as $file) {
            $html .= '<li><a class="sdrv-doc" href="' . esc_url($file['url']) . '" target="_blank" rel="noopener noreferrer">'
                . '<span class="sdrv-doc-ext" data-ext="' . esc_attr($file['ext']) . '">' . esc_html(strtoupper($file['ext'])) . '</span>'
                . '<span class="sdrv-doc-name">' . esc_html($section === 'formulare' ? self::pretty_name($file['name']) : $file['name']) . '</span>'
                . '<span class="sdrv-doc-size">' . esc_html(SetareDrive_Local::format_size($file['size'])) . '</span></a></li>';
        }
        return $html . '</ul>';
    }

    /* ---------------------------------------------------------------- formulare */

    /** Compartimentele definite în SetareDate (uid + denumire), în ordinea din meniu. */
    public static function applied_services() {
        $applied = get_option('setaredate_applied', array());
        $out     = array();
        if (is_array($applied) && !empty($applied['servicii']) && is_array($applied['servicii'])) {
            foreach ($applied['servicii'] as $service) {
                if (!empty($service['uid']) && !empty($service['nume'])) {
                    $out[] = array('uid' => (string) $service['uid'], 'nume' => (string) $service['nume']);
                }
            }
        }
        return $out;
    }

    /**
     * Butoanele paginii Formulare: câte unul pentru fiecare compartiment din SetareDate (cu subfolderul lui, dacă există,
     * sau marcat „gol”), apoi subfolderele care nu aparțin unui compartiment.
     *
     * @param array $folders Subfoldere: array('id' =>, 'name' =>, 't' => (opțional)).
     * @return array<int,array{comp:string,label:string,id:string,t:string,empty:bool}>
     */
    private static function formulare_entries(array $folders) {
        $entries = array();
        $used    = array();
        foreach (self::applied_services() as $service) {
            $match = self::match_folder($service, $folders);
            if ($match) {
                $used[$match['id']] = true;
            }
            $entries[] = array(
                'comp'  => $service['uid'],
                'label' => $service['nume'],
                'id'    => $match ? $match['id'] : '',
                't'     => $match && isset($match['t']) ? $match['t'] : '',
                'empty' => !$match,
            );
        }
        foreach ($folders as $folder) {
            if (!isset($used[$folder['id']])) {
                $entries[] = array('comp' => '', 'label' => self::pretty_name($folder['name']), 'id' => $folder['id'], 't' => isset($folder['t']) ? $folder['t'] : '', 'empty' => false);
            }
        }
        return $entries;
    }

    private static function empty_note() {
        return '<p class="sdrv-empty sdrv-empty-note" data-empty-note hidden>Nu există încă formulare pentru acest compartiment.</p>';
    }

    private static function button_html(array $entry, $source_is_local) {
        $attrs = ' data-folder="' . esc_attr($entry['id']) . '"';
        if ($entry['comp'] !== '') {
            $attrs .= ' data-comp="' . esc_attr($entry['comp']) . '"';
        }
        if ($entry['empty']) {
            $attrs .= ' data-empty="1"';
        }
        if ($source_is_local && $entry['t'] !== '') {
            $attrs .= ' data-token="' . esc_attr($entry['t']) . '"';
        }
        return '<button type="button" class="sdrv-folder-btn"' . $attrs . ' aria-pressed="false">' . esc_html($entry['label']) . '</button>';
    }

    public static function formulare() {
        self::enqueue('browser');
        $src = self::source('formulare');
        if ($src['type'] === 'none') {
            return self::notice('Formulare', 'Nu este setată locația formularelor (folder pe server sau ID Google Drive). Administratorul o poate adăuga în Setări → SetareDrive.', $src['detail']);
        }
        if ($src['type'] === 'local') {
            return self::formulare_local();
        }

        $root    = $src['id'];
        $detail  = $src['detail'];
        $folders = SetareDrive_API::folders($root, 60);
        if (is_wp_error($folders)) {
            $detail  = $folders->get_error_message();
            $folders = array();
        }
        $entries   = self::formulare_entries($folders);
        $has_files = $folders ? SetareDrive_API::has_files($root) : true;
        if ($has_files === true || is_wp_error($has_files)) {
            array_unshift($entries, array('comp' => '', 'label' => $entries ? 'Toate formularele' : 'Formulare', 'id' => $root, 't' => '', 'empty' => false));
        }
        $first = null;
        foreach ($entries as $entry) {
            if (!$entry['empty']) {
                $first = $entry;
                break;
            }
        }
        $initial = $first ? $first['id'] : ($entries ? '' : $root);

        ob_start();
        echo '<div class="sdrv-forms" data-sdrv-browser data-initial="' . esc_attr($initial) . '">';
        if ($detail !== '') {
            echo self::notice('Formulare', 'Lista subfolderelor nu poate fi încărcată momentan.', $detail);
        }
        if (count($entries) > 1) {
            echo '<div class="sdrv-buttons" role="group" aria-label="Categorii de formulare">';
            foreach ($entries as $entry) {
                echo self::button_html($entry, false);
            }
            echo '</div>';
        }
        echo '<div class="sdrv-viewer">' . self::empty_note() . self::viewer_frame() . '</div></div>';
        return ob_get_clean();
    }

    private static function formulare_local() {
        $folders = SetareDrive_Local::folders('formulare', '');
        $folders = is_wp_error($folders) ? array() : $folders;
        $entries = self::formulare_entries($folders);

        $root_files = SetareDrive_Local::files('formulare', '');
        $has_files  = !is_wp_error($root_files) && !empty($root_files);
        if ($has_files || !$entries) {
            $id = SetareDrive_Local::encode_id('');
            array_unshift($entries, array('comp' => '', 'label' => $entries ? 'Toate formularele' : 'Formulare', 'id' => $id, 't' => SetareDrive_Local::token('formulare', $id), 'empty' => false));
        }
        // Se afișează mai întâi primul buton care are fișiere (compartimentele goale rămân în listă).
        $first = null;
        foreach ($entries as $entry) {
            if (!$entry['empty']) {
                $first = $entry;
                break;
            }
        }

        ob_start();
        echo '<div class="sdrv-forms" data-sdrv-browser data-source="local" data-section="formulare" data-initial="' . esc_attr($first ? $first['id'] : '') . '" data-token="' . esc_attr($first ? $first['t'] : '') . '">';
        if (count($entries) > 1) {
            echo '<div class="sdrv-buttons" role="group" aria-label="Categorii de formulare">';
            foreach ($entries as $entry) {
                echo self::button_html($entry, true);
            }
            echo '</div>';
        }
        $note = self::empty_note();
        if (!$first) {
            $note = str_replace(' hidden>', '>', $note);
            $list = '';
        } else {
            $rel   = (string) SetareDrive_Local::decode_id($first['id']);
            $label = $rel === '' ? self::local_name('formulare', '') : $first['label'];
            $list  = self::local_list('formulare', $rel, $label);
        }
        echo '<div class="sdrv-viewer">' . $note . '<div class="sdrv-local" data-local-list aria-live="polite">' . $list . '</div></div></div>';
        return ob_get_clean();
    }

    /* -------------------------------------------------------------------- media */

    public static function media() {
        self::enqueue('media');
        $src = self::source('foto');
        $items = array();
        if ($src['type'] === 'local') {
            foreach (SetareDrive_Local::images('foto') as $image) {
                $items[] = array('big' => $image['big'], 'thumb' => $image['thumb'], 'video' => '');
            }
        } elseif ($src['type'] === 'drive') {
            $found = SetareDrive_API::media($src['id']);
            foreach (is_wp_error($found) ? array() : $found as $item) {
                $id      = rawurlencode($item['id']);
                $items[] = array(
                    'big'   => 'https://drive.google.com/thumbnail?id=' . $id . '&sz=w1600',
                    'thumb' => 'https://drive.google.com/thumbnail?id=' . $id . '&sz=w240',
                    'video' => strpos((string) $item['mimeType'], 'video/') === 0 ? 'https://drive.google.com/file/d/' . $id . '/preview' : '',
                );
            }
        }
        if (!$items) {
            return '';
        }

        $count = count($items);
        ob_start();
        ?>
        <section class="sdrv-gallery" data-sdrv-gallery role="region" aria-roledescription="carusel" aria-label="Galerie foto">
            <div class="sdrv-stage">
                <ol class="sdrv-track" data-track>
                    <?php foreach ($items as $i => $item) : ?>
                        <li class="sdrv-slide<?php echo $item['video'] !== '' ? ' is-video' : ''; ?>" data-slide aria-label="<?php echo esc_attr(($i + 1) . ' din ' . $count); ?>"<?php echo $item['video'] !== '' ? ' data-video="' . esc_url($item['video']) . '"' : ''; ?>>
                            <img src="<?php echo esc_url($item['big']); ?>" alt="" loading="<?php echo $i === 0 ? 'eager' : 'lazy'; ?>" decoding="async" referrerpolicy="no-referrer">
                        </li>
                    <?php endforeach; ?>
                </ol>
                <?php if ($count > 1) : ?>
                    <button type="button" class="sdrv-arrow sdrv-prev" data-prev aria-label="Fotografia anterioară" hidden>&#8249;</button>
                    <button type="button" class="sdrv-arrow sdrv-next" data-next aria-label="Fotografia următoare" hidden>&#8250;</button>
                <?php endif; ?>
            </div>
            <?php if ($count > 1) : ?>
                <div class="sdrv-rail" data-rail role="group" aria-label="Alegeți o fotografie" hidden>
                    <?php foreach ($items as $i => $item) : ?>
                        <button type="button" class="sdrv-thumb" data-thumb="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr('Fotografia ' . ($i + 1) . ' din ' . $count); ?>" aria-pressed="false">
                            <img src="<?php echo esc_url($item['thumb']); ?>" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    /* --------------------------------------------------------- Monitorul Oficial */

    private static function node($folder, $open_children = false) {
        $id = $folder['id'];
        $token = isset($folder['t']) ? $folder['t'] : SetareDrive_API::token($id);
        return '<li class="sdrv-node" data-id="' . esc_attr($id) . '" data-token="' . esc_attr($token) . '">'
            . '<div class="sdrv-node-row">'
            . '<button type="button" class="sdrv-toggle" aria-expanded="' . ($open_children ? 'true' : 'false') . '" aria-label="Arată subfolderele"><span aria-hidden="true"></span></button>'
            . '<button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($id) . '" aria-pressed="false"><span aria-hidden="true">📁</span> ' . esc_html($folder['name']) . '</button>'
            . '</div>'
            . '<ul class="sdrv-tree-list" role="group"' . ($open_children ? '' : ' hidden') . '></ul>'
            . '</li>';
    }

    private static function tree_root($root_id, $token, $label, $children) {
        $tree = '<ul class="sdrv-tree-list sdrv-tree-root" role="tree">'
            . '<li class="sdrv-node is-open" data-id="' . esc_attr($root_id) . '" data-token="' . esc_attr($token) . '" data-loaded="1">'
            . '<div class="sdrv-node-row"><button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($root_id) . '" aria-pressed="false"><span aria-hidden="true">📁</span> ' . esc_html($label) . '</button></div>'
            . '<ul class="sdrv-tree-list" role="group">';
        foreach ($children as $child) {
            $tree .= self::node($child);
        }
        return $tree . '</ul></li></ul>';
    }

    public static function mol() {
        self::enqueue('browser');
        $src     = self::source('mol');
        $type    = $src['type'];
        $message = 'Selectați un folder din listă pentru a vedea documentele.';
        $tree    = '';
        $detail  = $src['detail'];
        $initial = '';
        $token   = '';
        $viewer  = '';

        if ($type === 'none') {
            $message = 'Nu este setată locația documentelor (folder pe server sau ID Google Drive). Administratorul o poate adăuga în Setări → SetareDrive.';
        } elseif ($type === 'local') {
            $initial  = SetareDrive_Local::encode_id('');
            $token    = SetareDrive_Local::token('mol', $initial);
            $children = SetareDrive_Local::folders('mol', '');
            $label    = self::local_name('mol', '');
            $tree     = self::tree_root($initial, $token, $label !== '' ? $label : 'Monitorul Oficial Local', is_wp_error($children) ? array() : $children);
            $viewer   = '<div class="sdrv-local" data-local-list aria-live="polite">' . self::local_list('mol', '', $label) . '</div>';
        } else {
            $initial  = $src['id'];
            $token    = SetareDrive_API::token($initial);
            $children = SetareDrive_API::folders($initial);
            if (is_wp_error($children)) {
                $detail = $children->get_error_message();
                $tree   = '<p class="sdrv-tree-empty">Lista de foldere nu poate fi încărcată momentan. Conținutul principal rămâne disponibil în caseta din dreapta.</p>';
            } else {
                $name = SetareDrive_API::folder_name($initial);
                $tree = self::tree_root($initial, $token, $name !== '' ? $name : 'Monitorul Oficial Local', $children);
            }
            $viewer = self::viewer_frame();
        }

        ob_start();
        ?>
        <div class="sdrv-mol" data-sdrv-browser data-sdrv-mol<?php echo $type === 'local' ? ' data-source="local" data-section="mol"' : ''; ?> data-initial="<?php echo esc_attr($initial); ?>" data-token="<?php echo esc_attr($token); ?>">
            <?php echo self::notice('Arhiva oficială de documente', $message, $detail); ?>
            <div class="sdrv-layout">
                <nav class="sdrv-tree" aria-label="Foldere Monitorul Oficial Local">
                    <h2>Structura arhivei</h2>
                    <?php echo $tree; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                </nav>
                <section class="sdrv-viewer" aria-label="Documentele din folderul selectat">
                    <div class="sdrv-selected"><strong>Folder selectat:</strong> <span data-selected>—</span></div>
                    <form class="sdrv-search" data-search-form>
                        <label for="sdrv-search-input">Caută în numele fișierelor din folderul selectat</label>
                        <div><input id="sdrv-search-input" type="search" data-search-input placeholder="Ex.: hotărâre, buget, dispoziție…"><button class="sdrv-btn" type="submit">Caută</button></div>
                        <label class="sdrv-check"><input type="checkbox" data-search-all> Caută în toate subfolderele (în tot Monitorul Oficial Local)</label>
                    </form>
                    <p class="sdrv-search-note" data-search-note></p>
                    <div class="sdrv-results" data-search-results aria-live="polite"></div>
                    <?php echo $viewer; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                </section>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ------------------------------------- Formulare pe subpaginile compartimentelor */

    /** Compartimentul (din SetareDate) a cărui subpagină are acest ID. @return array|null */
    private static function service_for_page($page_id) {
        $applied = get_option('setaredate_applied', array());
        $list    = (is_array($applied) && isset($applied['servicii']) && is_array($applied['servicii'])) ? $applied['servicii'] : array();
        foreach ($list as $service) {
            if (isset($service['page_id']) && (int) $service['page_id'] === (int) $page_id && (int) $page_id > 0) {
                return $service;
            }
        }
        return null;
    }

    /**
     * Subfolderul din folderul Formulare care corespunde compartimentului: același nume, același început
     * (ex. „urbanism” pentru „Urbanism & Amenajare”), un cuvânt din denumire sau denumiri foarte asemănătoare.
     *
     * @param array $folders Liste de forma array('name' => …, …).
     * @return array|null
     */
    public static function match_folder(array $service, array $folders) {
        $wanted = array();
        foreach (array('nume', 'uid') as $field) {
            if (!empty($service[$field])) {
                $slug = sanitize_title((string) $service[$field]);
                if ($slug !== '') {
                    $wanted[$field] = $slug;
                }
            }
        }
        // Denumiri suplimentare pentru potrivire (ex.: add_filter('setaredrive_service_folder_names', fn($n, $service) => ...)).
        foreach ((array) apply_filters('setaredrive_service_folder_names', array(), $service) as $extra) {
            $slug = sanitize_title((string) $extra);
            if ($slug !== '') {
                $wanted['extra' . count($wanted)] = $slug;
            }
        }
        $best       = null;
        $best_score = 0;
        foreach ($folders as $folder) {
            $slug = sanitize_title((string) $folder['name']);
            if ($slug === '') {
                continue;
            }
            $tokens = explode('-', $slug);
            $score  = 0;
            foreach ($wanted as $field => $w) {
                if ($slug === $w) {
                    $current = 100;
                } elseif (strlen($w) >= 4 && strlen($slug) >= 4 && (strpos($w, $slug . '-') === 0 || strpos($slug, $w . '-') === 0)) {
                    $current = 90;
                } elseif ($field === 'uid' && in_array($w, $tokens, true)) {
                    $current = 85;
                } else {
                    similar_text($w, $slug, $percent);
                    $current = $percent >= 80 ? $percent : 0;
                }
                $score = max($score, $current);
            }
            if ($score > $best_score) {
                $best_score = $score;
                $best       = $folder;
            }
        }
        return $best_score >= 80 ? $best : null;
    }

    /** Nume lizibil pentru fișiere încărcate cu denumiri de tip „cerere-divort-cale-administrativa”. */
    public static function pretty_name($name) {
        $name = (string) $name;
        if ($name === '' || preg_match('/\s/u', $name) || !preg_match('/[-_]/', $name)) {
            return $name;
        }
        $name = trim(preg_replace('/\s+/u', ' ', str_replace(array('-', '_'), ' ', $name)));
        if (function_exists('mb_strtoupper') && function_exists('mb_substr')) {
            return mb_strtoupper(mb_substr($name, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($name, 1, null, 'UTF-8');
        }
        return ucfirst($name);
    }

    private static function size_label($bytes) {
        $bytes = (int) $bytes;
        if ($bytes <= 0) {
            return '';
        }
        return $bytes >= 1048576 ? number_format_i18n($bytes / 1048576, 1) . ' MB' : number_format_i18n(max(1, round($bytes / 1024))) . ' KB';
    }

    /**
     * Fișierele din subfolderul corespunzător unui compartiment, citite la fiecare cerere
     * (folder pe server: direct; Google Drive: memorie cache de cel mult 60 de secunde).
     *
     * @return array{matched:bool,folder:string,items:array}|null Null dacă pagina nu este un compartiment sau nu există sursă.
     */
    public static function service_files($page_id) {
        $service = self::service_for_page($page_id);
        if (!$service) {
            return null;
        }
        $src   = self::source('formulare');
        $items = array();
        if ($src['type'] === 'local') {
            $folders = SetareDrive_Local::folders('formulare', '');
            if (is_wp_error($folders)) {
                return null;
            }
            $match = self::match_folder($service, $folders);
            if (!$match) {
                return array('matched' => false, 'folder' => '', 'items' => array());
            }
            $files = SetareDrive_Local::files('formulare', (string) SetareDrive_Local::decode_id($match['id']));
            foreach (is_wp_error($files) ? array() : $files as $file) {
                $items[] = array('name' => self::pretty_name($file['name']), 'ext' => $file['ext'], 'size' => SetareDrive_Local::format_size($file['size']), 'url' => $file['url']);
            }
        } elseif ($src['type'] === 'drive') {
            $folders = SetareDrive_API::folders($src['id'], 60);
            if (is_wp_error($folders)) {
                return null;
            }
            $match = self::match_folder($service, $folders);
            if (!$match) {
                return array('matched' => false, 'folder' => '', 'items' => array());
            }
            $files = SetareDrive_API::files_fresh($match['id']);
            foreach (is_wp_error($files) ? array() : $files as $file) {
                $name    = (string) $file['name'];
                $items[] = array(
                    'name' => self::pretty_name(preg_replace('/\.[A-Za-z0-9]{2,5}$/', '', $name)),
                    'ext'  => strtolower((string) pathinfo($name, PATHINFO_EXTENSION)),
                    'size' => self::size_label(isset($file['size']) ? $file['size'] : 0),
                    'url'  => isset($file['webViewLink']) ? (string) $file['webViewLink'] : 'https://drive.google.com/open?id=' . rawurlencode($file['id']),
                );
            }
            usort($items, function ($a, $b) {
                return strnatcasecmp($a['name'], $b['name']);
            });
        } else {
            return null;
        }
        return array('matched' => true, 'folder' => (string) $match['name'], 'items' => $items);
    }

    /** Secțiunea „Formulare” de pe subpagina unui compartiment. */
    public static function service_forms_html($page_id) {
        $data = self::service_files($page_id);
        if ($data === null) {
            return '';
        }
        if (!$data['matched']) {
            $service = self::service_for_page($page_id);
            return current_user_can('manage_options')
                ? '<p class="sdrv-admin-note">Vizibil doar administratorilor: în folderul Formulare nu există un subfolder pentru acest compartiment (nume așteptat: „' . esc_html($service ? $service['nume'] : '') . '”).</p>'
                : '';
        }
        self::enqueue('svc');
        $hidden = $data['items'] ? '' : ' hidden';
        $html   = '<section class="sdrv-svc-forms" data-sdrv-svc-forms data-page="' . esc_attr((int) $page_id) . '"' . $hidden . '>'
            . '<h2>Formulare pentru acest compartiment</h2><ul class="sdrv-doclist" data-svc-list>';
        foreach ($data['items'] as $item) {
            $html .= '<li><a class="sdrv-doc" href="' . esc_url($item['url']) . '" target="_blank" rel="noopener noreferrer">'
                . '<span class="sdrv-doc-ext" data-ext="' . esc_attr($item['ext']) . '">' . esc_html(strtoupper($item['ext'])) . '</span>'
                . '<span class="sdrv-doc-name">' . esc_html($item['name']) . '</span>'
                . '<span class="sdrv-doc-size">' . esc_html($item['size']) . '</span></a></li>';
        }
        $html .= '</ul><p class="sdrv-svc-all"><a href="' . esc_url(function_exists('pbv_page_url') ? pbv_page_url('formulare', '/formulare/') : home_url('/formulare/')) . '">Toate formularele &rarr;</a></p></section>';
        return $html;
    }

    public static function service_shortcode() {
        return self::service_forms_html((int) get_the_ID());
    }

    /** Adaugă formularele la sfârșitul subpaginilor de compartiment (fără a modifica conținutul paginii din WordPress). */
    public static function append_service_forms($content) {
        if (!is_singular('page') || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        if (has_shortcode($content, 'setaredrive_formulare_compartiment')) {
            return $content;
        }
        return $content . self::service_forms_html((int) get_the_ID());
    }

    public static function rest_service_forms($request) {
        $data = self::service_files((int) $request['page']);
        if ($data === null) {
            return new WP_Error('setaredrive_not_found', 'Compartiment necunoscut.', array('status' => 404));
        }
        $response = rest_ensure_response(array('matched' => $data['matched'], 'folder' => $data['folder'], 'items' => $data['items']));
        $response->header('Cache-Control', 'no-store, max-age=0');
        return $response;
    }

    /* ------------------------------------------------------------------- Ziarul local */

    private static function ziar_viewer() {
        return '<section class="sdrv-ziar-viewer" aria-label="Vizualizare ediție">'
            . '<div class="sdrv-ziar-bar"><strong class="sdrv-ziar-title" data-ziar-title></strong>'
            . '<span class="sdrv-ziar-actions"><a data-ziar-open href="#" target="_blank" rel="noopener noreferrer">Deschide în filă nouă</a><a data-ziar-download href="#">Descarcă</a></span></div>'
            . '<div class="sdrv-ziar-frame"><iframe data-ziar-frame title="Ediția selectată" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>'
            . '</section>';
    }

    /**
     * Ziarul local: în stânga lista fișierelor PDF din folder (fără subfoldere), în dreapta, pe cât mai mult din lățime,
     * PDF-ul ales. Cele mai noi (după nume, în ordine descrescătoare) sunt primele.
     */
    public static function ziar() {
        self::enqueue('ziar');
        $src = self::source('ziar');
        if ($src['type'] === 'none') {
            return self::notice('Ziarul local', 'Nu este setată locația ziarului local (folder pe server sau ID Google Drive). Administratorul o poate adăuga în Setări → SetareDrive.', $src['detail']);
        }

        $items  = array();
        $detail = $src['detail'];
        if ($src['type'] === 'local') {
            $files = SetareDrive_Local::files('ziar', '');
            foreach (is_wp_error($files) ? array() : $files as $file) {
                if ($file['ext'] !== 'pdf') {
                    continue;
                }
                $items[] = array(
                    'id'       => SetareDrive_Local::encode_id($file['file']),
                    'name'     => $file['name'],
                    'view'     => $file['url'] . '#view=FitH',
                    'open'     => $file['url'],
                    'download' => add_query_arg('dl', '1', $file['url']),
                );
            }
        } else {
            $files = SetareDrive_API::pdfs($src['id']);
            if (is_wp_error($files)) {
                $detail = $files->get_error_message();
                // Fără listă (de exemplu fără cheie API) se afișează folderul Google Drive în toată zona.
                return '<div class="sdrv-ziar sdrv-ziar--fallback">'
                    . ($detail !== '' && current_user_can('manage_options') ? self::notice('Ziarul local', 'Lista edițiilor nu poate fi încărcată; se afișează folderul Google Drive.', $detail) : '')
                    . '<div class="sdrv-frame-wrap"><iframe class="sdrv-frame" title="Folderul Ziarul local" src="' . esc_url(self::embed_url($src['id'])) . '"></iframe></div>'
                    . '<p class="sdrv-open"><a href="' . esc_url(self::open_url($src['id'])) . '" target="_blank" rel="noopener noreferrer">Deschide folderul în Google Drive</a></p></div>';
            }
            foreach ($files as $file) {
                $id      = rawurlencode($file['id']);
                $items[] = array(
                    'id'       => $file['id'],
                    'name'     => preg_replace('/\.pdf$/i', '', (string) $file['name']),
                    'view'     => 'https://drive.google.com/file/d/' . $id . '/preview',
                    'open'     => 'https://drive.google.com/file/d/' . $id . '/view',
                    'download' => 'https://drive.google.com/uc?export=download&id=' . $id,
                );
            }
        }
        if (!$items) {
            return self::notice('Ziarul local', 'Nu există încă ediții în folderul ziarului local.', $detail);
        }
        usort($items, function ($a, $b) {
            return strnatcasecmp($b['name'], $a['name']);
        });

        ob_start();
        ?>
        <div class="sdrv-ziar" data-sdrv-ziar>
            <aside class="sdrv-ziar-list" aria-label="Edițiile ziarului local">
                <div class="sdrv-ziar-head"><strong>Ediții</strong> <span class="sdrv-ziar-count" data-ziar-count><?php echo esc_html(count($items)); ?></span></div>
                <input type="search" class="sdrv-ziar-filter" data-ziar-filter placeholder="Caută o ediție…" aria-label="Filtrează edițiile">
                <ul class="sdrv-ziar-items" data-ziar-items>
                    <?php foreach ($items as $item) : ?>
                        <li><a class="sdrv-ziar-item" href="<?php echo esc_url($item['open']); ?>" target="_blank" rel="noopener noreferrer"
                               data-id="<?php echo esc_attr($item['id']); ?>" data-name="<?php echo esc_attr($item['name']); ?>"
                               data-view="<?php echo esc_url($item['view']); ?>" data-open="<?php echo esc_url($item['open']); ?>" data-download="<?php echo esc_url($item['download']); ?>">
                            <span class="sdrv-ziar-icon" aria-hidden="true">PDF</span><span class="sdrv-ziar-name"><?php echo esc_html($item['name']); ?></span></a></li>
                    <?php endforeach; ?>
                </ul>
                <p class="sdrv-ziar-none" data-ziar-none hidden>Nicio ediție găsită.</p>
            </aside>
            <?php echo self::ziar_viewer(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* --------------------------------------------------------------------- REST */

    public static function routes() {
        register_rest_route(self::REST_NS, '/children', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'rest_children'),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            ),
        ));
        register_rest_route(self::REST_NS, '/service-forms', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'rest_service_forms'),
            'permission_callback' => '__return_true',
            'args'                => array('page' => array('required' => true, 'sanitize_callback' => 'absint')),
        ));
        foreach (array('children' => 'rest_local_children', 'files' => 'rest_local_files', 'search' => 'rest_local_search') as $route => $callback) {
            $args = array(
                'sec' => array('required' => true, 'sanitize_callback' => 'sanitize_key'),
                'id'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'   => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            );
            if ($route === 'search') {
                $args['q']   = array('required' => true, 'sanitize_callback' => 'sanitize_text_field');
                $args['all'] = array('required' => false, 'sanitize_callback' => 'absint');
            }
            register_rest_route(self::REST_NS, '/local/' . $route, array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, $callback),
                'permission_callback' => '__return_true',
                'args'                => $args,
            ));
        }
        register_rest_route(self::REST_NS, '/search', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'rest_search'),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                'q'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                'all' => array('required' => false, 'sanitize_callback' => 'absint'),
            ),
        ));
    }

    public static function rest_children($request) {
        $id = SetareDrive_API::clean_id($request['id']);
        if (!SetareDrive_API::valid_token($id, $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $folders = SetareDrive_API::folders($id);
        if (is_wp_error($folders)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        $out = array();
        foreach ($folders as $folder) {
            $out[] = array('id' => $folder['id'], 'name' => $folder['name'], 't' => SetareDrive_API::token($folder['id']));
        }
        return rest_ensure_response(array('folders' => $out));
    }

    public static function rest_search($request) {
        $id = SetareDrive_API::clean_id($request['id']);
        if (!SetareDrive_API::valid_token($id, $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $term = trim((string) $request['q']);
        if ($term === '') {
            return rest_ensure_response(array('files' => array()));
        }
        if (!empty($request['all'])) {
            @set_time_limit(60);
            $found = SetareDrive_API::search_tree($id, $term);
            if (is_wp_error($found)) {
                return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
            }
            return rest_ensure_response($found);
        }
        $files = SetareDrive_API::files($id);
        if (is_wp_error($files)) {
            return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
        }
        $out = array();
        foreach ($files as $file) {
            if (mb_stripos((string) $file['name'], $term, 0, 'UTF-8') === false) {
                continue;
            }
            $out[] = array(
                'name' => (string) $file['name'],
                'url'  => isset($file['webViewLink']) ? (string) $file['webViewLink'] : 'https://drive.google.com/open?id=' . rawurlencode($file['id']),
                'date' => isset($file['modifiedTime']) ? (string) $file['modifiedTime'] : '',
            );
            if (count($out) >= 200) {
                break;
            }
        }
        return rest_ensure_response(array('files' => $out));
    }

    /* ---- sursa „folder pe server” ---- */

    private static function local_rel($request) {
        $section = (string) $request['sec'];
        $id      = (string) $request['id'];
        if (!SetareDrive_Local::valid($section, $id, (string) $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $rel = SetareDrive_Local::decode_id($id);
        if ($rel === false || SetareDrive_Local::path($section, $rel) === false) {
            return new WP_Error('setaredrive_missing', 'Folderul nu a fost găsit.', array('status' => 404));
        }
        return array($section, $rel);
    }

    public static function rest_local_children($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $folders = SetareDrive_Local::folders($target[0], $target[1]);
        if (is_wp_error($folders)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        return rest_ensure_response(array('folders' => $folders));
    }

    private static function local_files_payload($files, $section = '') {
        $out = array();
        foreach ($files as $file) {
            $out[] = array(
                'name' => $section === 'formulare' ? self::pretty_name($file['name']) : $file['name'],
                'ext'  => $file['ext'],
                'size' => SetareDrive_Local::format_size($file['size']),
                'date' => $file['mtime'] ? gmdate('c', $file['mtime']) : '',
                'url'  => $file['url'],
            );
        }
        return $out;
    }

    public static function rest_local_files($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $files = SetareDrive_Local::files($target[0], $target[1]);
        if (is_wp_error($files)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        return rest_ensure_response(array(
            'name'  => self::local_name($target[0], $target[1]),
            'count' => count($files),
            'subfolders' => ($sub = SetareDrive_Local::folders($target[0], $target[1])) && !is_wp_error($sub) ? count($sub) : 0,
            'files' => self::local_files_payload($files, $target[0]),
        ));
    }

    public static function rest_local_search($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $term = trim((string) $request['q']);
        if ($term !== '' && !empty($request['all'])) {
            $found = SetareDrive_Local::search_tree($target[0], $target[1], $term);
            if (is_wp_error($found)) {
                return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
            }
            return rest_ensure_response($found);
        }
        $files = SetareDrive_Local::files($target[0], $target[1]);
        if ($term === '' || is_wp_error($files)) {
            return rest_ensure_response(array('files' => array()));
        }
        $matches = array();
        foreach ($files as $file) {
            if (mb_stripos($file['file'], $term, 0, 'UTF-8') !== false) {
                $matches[] = $file;
            }
        }
        return rest_ensure_response(array('files' => array_slice(self::local_files_payload($matches), 0, 200)));
    }
}
