(function () {
  'use strict';

  var cfg = window.SetareDriveSvc || { rest: '' };

  function render(list, items) {
    list.replaceChildren();
    items.forEach(function (file) {
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.className = 'sdrv-doc';
      a.href = file.url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      var ext = document.createElement('span');
      ext.className = 'sdrv-doc-ext';
      ext.setAttribute('data-ext', file.ext);
      ext.textContent = String(file.ext).toUpperCase();
      var name = document.createElement('span');
      name.className = 'sdrv-doc-name';
      name.textContent = file.name;
      var size = document.createElement('span');
      size.className = 'sdrv-doc-size';
      size.textContent = file.size;
      a.appendChild(ext);
      a.appendChild(name);
      a.appendChild(size);
      li.appendChild(a);
      list.appendChild(li);
    });
  }

  /* La afișarea paginii se verifică din nou folderul compartimentului; dacă un sistem de cache a păstrat o
     versiune mai veche a paginii, lista se actualizează cu fișierele curente. */
  function refresh(box) {
    var list = box.querySelector('[data-svc-list]');
    if (!list || !cfg.rest) { return; }
    var url = cfg.rest + 'service-forms?page=' + encodeURIComponent(box.getAttribute('data-page')) + '&_=' + Date.now();
    fetch(url, { credentials: 'omit', cache: 'no-store' }).then(function (response) {
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      return response.json();
    }).then(function (data) {
      if (!data || !data.items) { return; }
      var fresh = data.items.map(function (item) { return item.url; }).join('|');
      var shown = Array.prototype.map.call(list.querySelectorAll('a.sdrv-doc'), function (a) { return a.getAttribute('href'); }).join('|');
      if (fresh !== shown) { render(list, data.items); }
      box.hidden = data.items.length === 0;
    }).catch(function () { /* se păstrează lista afișată de server */ });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-sdrv-svc-forms]').forEach(refresh);
  });
}());
