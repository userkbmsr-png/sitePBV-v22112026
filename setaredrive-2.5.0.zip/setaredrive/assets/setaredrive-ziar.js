(function () {
  'use strict';

  function init(root) {
    var list = root.querySelector('[data-ziar-items]');
    var items = Array.prototype.slice.call(root.querySelectorAll('.sdrv-ziar-item'));
    var frame = root.querySelector('[data-ziar-frame]');
    var title = root.querySelector('[data-ziar-title]');
    var openLink = root.querySelector('[data-ziar-open]');
    var downloadLink = root.querySelector('[data-ziar-download]');
    var filter = root.querySelector('[data-ziar-filter]');
    var count = root.querySelector('[data-ziar-count]');
    var none = root.querySelector('[data-ziar-none]');
    if (!items.length || !frame) { return; }

    function select(item, updateHash) {
      items.forEach(function (other) {
        var on = other === item;
        other.classList.toggle('is-selected', on);
        if (on) { other.setAttribute('aria-current', 'true'); } else { other.removeAttribute('aria-current'); }
      });
      frame.src = item.getAttribute('data-view');
      if (title) { title.textContent = item.getAttribute('data-name'); }
      if (openLink) { openLink.href = item.getAttribute('data-open'); }
      if (downloadLink) { downloadLink.href = item.getAttribute('data-download'); }
      if (updateHash && window.history && history.replaceState) {
        history.replaceState(null, '', '#' + item.getAttribute('data-id'));
      }
      if (item.scrollIntoView) { item.scrollIntoView({ block: 'nearest' }); }
    }

    function visibleItems() {
      return items.filter(function (item) { return !item.parentNode.hidden; });
    }

    list.addEventListener('click', function (event) {
      var item = event.target.closest ? event.target.closest('.sdrv-ziar-item') : null;
      if (!item) { return; }
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button === 1) { return; }
      event.preventDefault();
      select(item, true);
    });

    // Săgeți sus/jos: trece la ediția vecină și o afișează.
    list.addEventListener('keydown', function (event) {
      if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') { return; }
      var current = event.target.closest ? event.target.closest('.sdrv-ziar-item') : null;
      var visible = visibleItems();
      var index = visible.indexOf(current);
      if (index < 0) { return; }
      var next = visible[index + (event.key === 'ArrowDown' ? 1 : -1)];
      if (next) {
        event.preventDefault();
        next.focus();
        select(next, true);
      }
    });

    if (filter) {
      filter.addEventListener('input', function () {
        var term = filter.value.trim().toLowerCase();
        var shown = 0;
        items.forEach(function (item) {
          var match = !term || item.getAttribute('data-name').toLowerCase().indexOf(term) !== -1;
          item.parentNode.hidden = !match;
          if (match) { shown += 1; }
        });
        if (count) { count.textContent = String(shown); }
        if (none) { none.hidden = shown !== 0; }
      });
    }

    function fromHash() {
      var id = decodeURIComponent((window.location.hash || '').replace(/^#/, ''));
      if (!id) { return null; }
      return items.filter(function (item) { return item.getAttribute('data-id') === id; })[0] || null;
    }

    window.addEventListener('hashchange', function () {
      var target = fromHash();
      if (target) { select(target, false); }
    });

    select(fromHash() || items[0], false);
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-sdrv-ziar]').forEach(init);
  });
}());
